﻿using Microsoft.EntityFrameworkCore;

namespace OnlineExam_1.Models
{
    public class InventoryDBContext:DbContext
    {
        public InventoryDBContext(DbContextOptions options) : base(options) 
        { 
        } 
    }
}
