﻿using Microsoft.AspNetCore.Mvc;
using OnlineExam_1.Models;

namespace OnlineExam_1.Controllers
{
    public class AdminController : Controller
    {
        InventoryDBContext db = null;
        public IActionResult Index()
        {
            return View();
        }
    }
}
