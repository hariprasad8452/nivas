﻿using Microsoft.EntityFrameworkCore;

namespace OnlineWebAPI.Models
{
    public class ExamDBContext:DbContext

    {
        public ExamDBContext(DbContextOptions<ExamDBContext> options):base(options) 
        {
            
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Role>().HasData(
                new Role { RoleId = 1, RoleName = "Administrator" },
                new Role { RoleId = 2, RoleName = "User" });
            modelBuilder.Entity<User>().HasData(
                new User
                {
                    UserName = "admin@gmail.com",
                    FirstName="Exam",
                    LastName="Admin",
                    Age=30,
                    Gender="Male",
                    Password="admin",
                    Address="Hyderabad",
                    PhoneNumber=987654321,
                    RoleId=1

                });
            modelBuilder.Entity<Category>().HasData(
               new Category { CategoryId = 1, CategoryName = "C", Difficulty_Level = 1 },
               new Category { CategoryId = 2, CategoryName = "C", Difficulty_Level = 2 },
               new Category { CategoryId = 3, CategoryName = "C", Difficulty_Level = 3 },
               new Category { CategoryId = 4, CategoryName = "CPP", Difficulty_Level = 1 },
               new Category { CategoryId = 5, CategoryName = "CPP", Difficulty_Level = 2 },
               new Category { CategoryId = 6, CategoryName = "CPP", Difficulty_Level = 3 },
               new Category { CategoryId = 7, CategoryName = "C#", Difficulty_Level = 1 },
               new Category { CategoryId = 8, CategoryName = "C#", Difficulty_Level = 2 },
               new Category { CategoryId = 9, CategoryName = "C#", Difficulty_Level = 3 }
               );
            base.OnModelCreating(modelBuilder);
        }
        public virtual DbSet<User> Users { get; set; }
        public DbSet<Role> Roles { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Exam> Exams { get; set; }
        public DbSet<Question> Questions { get; set; }
    }
}
