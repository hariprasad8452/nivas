﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OnlineWebAPI.Models;

namespace OnlineWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ExamController : ControllerBase
    {
        ExamDBContext db = null;
        public ExamController(ExamDBContext context)
        {
            db = context;
        }
        [Route("Get")]
        [HttpGet]
        public ActionResult<IEnumerable<Exam>> GetExams()
        {
            var exams = db.Exams.ToList();
            return Ok(exams);
        }
        [Route("GetById")]
        [HttpGet]
        public ActionResult<Exam> GetExamById(int id)
        {
            var exam = db.Exams.FirstOrDefault(e => e.ExamId == id);
            if (exam == null)
            {
                return NotFound();
            }
            return Ok(exam);
        }
        [Route("CreateExam")]
        [HttpPost]
        public ActionResult<Exam> CreateExam(Exam exam)
        {
            db.Exams.Add(exam);
            db.SaveChanges();
            return CreatedAtAction(nameof(GetExamById), new { id = exam.ExamId }, exam);
        }
        [Route("UpdateExam")]
        [HttpPut]
        public IActionResult UpdateExam(int id, Exam exam)
        {
            if (id != exam.ExamId)
            {
                return BadRequest();
            }
            db.Entry(exam).State = EntityState.Modified;
            db.SaveChanges();
            return NoContent();
        }
        [Route("DeleteExam")]
        [HttpDelete]
        public IActionResult DeleteExam(int id)
        {
            var exam = db.Exams.FirstOrDefault(e => e.ExamId == id);
            if (exam == null)
            {
                return NotFound();
            }
            db.Exams.Remove(exam);
            db.SaveChanges();
            return NoContent();
        }
        [Route("AddQuestions")]
        [HttpPost]
        public ActionResult<Question> AddQuestionToExam(int id, Question question)
        {
            var exam = db.Exams.FirstOrDefault(e => e.ExamId == id);
            if (exam == null)
            {
                return NotFound();
            }
            question.ExamId = exam.ExamId;
            db.Questions.Add(question);
            db.SaveChanges();

            return CreatedAtAction("GetQuestionById", "Question", new { id = question.QuestionId }, question);
        }
    }
}

