﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OnlineWebAPI.Models;

namespace OnlineWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        ExamDBContext db = null;
        public LoginController(ExamDBContext context)
        {
            db = context;
        }
        [Route("Register")]
        [HttpPost]
        public IActionResult Register([FromBody] RegisterView Register)
        {
            if (Register == null)
            {
                return BadRequest();
            }
            string username = GenerateUserName(Register.FirstName, Register.LastName);
            if (ModelState.IsValid)
            {
                var user = new User();
                user.UserName = username;
                user.Password = Register.Password;
                user.FirstName = Register.FirstName;
                user.LastName = Register.LastName;
                user.Age = Register.Age;
                user.Gender = Register.Gender;
                user.Address = Register.Address;
                user.PhoneNumber = Register.PhoneNumber;
                user.RoleId = 2;
                db.Users.Add(user);
                db.SaveChanges();
                return Ok("Registration Success");
            }
            return BadRequest("Invalid Registration....!");
        }
        [HttpGet]
        public string GenerateUserName(string firstName, string lastName)
        {
            string username = (firstName.Substring(0, Math.Min(3, firstName.Length)).ToLower()) + "@" +
                (lastName.Substring(0, Math.Min(3, lastName.Length)).ToLower());
            return username;
        }
        [Route("LoginUser")]
        [HttpPost]
        public IActionResult Login([FromBody] LoginView loginUser)
        {
            if (loginUser == null)
            {
                return BadRequest();
            }
            var user = (from u in db.Users
                        where u.UserName== loginUser.EmailId
                        &&
                        u.Password == loginUser.Password
                        select u).SingleOrDefault();
            if (user == null)
            {
                return BadRequest("Invalid Login Credintials");
            }
            else
            {
                return Ok("welcome");
            }
        }

    }
    
}
