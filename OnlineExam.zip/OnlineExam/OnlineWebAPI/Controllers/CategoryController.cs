﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OnlineWebAPI.Models;

namespace OnlineWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoryController : ControllerBase
    {
        ExamDBContext db = null;
        public CategoryController(ExamDBContext context)
        {
            db = context;
        }
        [Route("GetByID")]
        [HttpGet]
        public ActionResult<IEnumerable<Category>> GetChoices()
        {
            var choices = db.Categories.ToList();
            return Ok(choices);
        }
        [Route("Add")]
        [HttpPost]
        public ActionResult<Category> CreateChoice(Category category)
        {
            db.Categories.Add(category);
            db.SaveChanges();
            return CreatedAtAction(nameof(GetCategoryById), new { id = category.CategoryId }, category);
        }
        [Route("GetID")]
        [HttpGet]
        public ActionResult<Category> GetCategoryById(int id)
        {
            var category = db.Categories.FirstOrDefault(c => c.CategoryId == id);
            if (category == null)
            {
                return NotFound();
            }
            return Ok(category);
        }
        [Route("Update")]
        [HttpPut]
        public IActionResult UpdateChoice(int id, Category category)
        {
            if (id != category.CategoryId)
            {
                return BadRequest();
            }
            db.Entry(category).State = EntityState.Modified;
            db.SaveChanges();
            return NoContent();
        }
        [Route("Delete")]
        [HttpDelete]
        public IActionResult DeleteCategory(int id)
        {
            var category = db.Categories.FirstOrDefault(c => c.CategoryId == id);
            if (category == null)
            {
                return NotFound();
            }
            db.Categories.Remove(category);
            db.SaveChanges();
            return NoContent();
        }
    }
}

