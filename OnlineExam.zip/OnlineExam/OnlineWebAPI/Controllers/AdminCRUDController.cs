﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OnlineWebAPI.Models;

namespace OnlineWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminCRUDController : ControllerBase
    {
        ExamDBContext db = null;
        public AdminCRUDController(ExamDBContext context)
        {
            db = context;
        }
        [Route("ViewUsers")]
        [HttpGet]
        public IActionResult ViewUsers()
        {
            var users = db.Users.ToList();
            return Ok(users);
        }
        [Route("AddQuestion")]
        [HttpPost]
        public IActionResult AddQuestion(Question question)
        {
            if (question == null)
            {
                return BadRequest();
            }
            if (ModelState.IsValid)
            {
                db.Questions.Add(question);
                db.SaveChanges();
                return Ok(question);
            }
            return Ok();
        }
        [Route("ViewQuestion")]
        [HttpPost]
        public IActionResult ViewQuestion()
        {
            var questions = db.Questions.ToList();
            return Ok(questions);
        }
        [Route("DeleteQuestion")]
        [HttpPost]
        public IActionResult DeleteQuestion(int id)
        {
            var questions = db.Questions.Find(id);
            if (questions == null)
            {
                return BadRequest();
            }
            else
            {
                db.Questions.Remove(questions);
                db.SaveChanges();
            }
            return Ok();
        }
        [Route("UpdateQuestion")]
        [HttpPost]
        public IActionResult UpdateQuestions(int id, Question modifiedquestion)
        {
            var questions = db.Questions.Find(id);
            if (questions != null)
            {
                questions.QuestionText = modifiedquestion.QuestionText;
                questions.Option_1 = modifiedquestion.Option_1;
                questions.Option_2 = modifiedquestion.Option_2;
                questions.Option_3 = modifiedquestion.Option_3;
                questions.Option_4 = modifiedquestion.Option_4;
                questions.Answer = modifiedquestion.Answer;
                questions.ExamId = modifiedquestion.ExamId;
                db.SaveChanges();
                return Ok(questions);
            }
            return Ok(questions);
        }
    }
}
