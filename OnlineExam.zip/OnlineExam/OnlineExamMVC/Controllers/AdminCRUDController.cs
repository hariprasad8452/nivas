﻿using Microsoft.AspNetCore.Mvc;
using OnlineWebAPI.Models;

namespace OnlineExamMVC.Controllers
{
    public class AdminCRUDController : Controller
    {
        Uri basedaddress = new Uri("http://localhost:9748/api");
        private readonly HttpClient _httpClient;
        public AdminCRUDController()
        {
            _httpClient = new HttpClient();
            _httpClient.BaseAddress = basedaddress;
        }
        public IActionResult Index()
        {
            //List<Login> userList = new List<Login>();
            //HttpResponseMessage response = _httpClient.GetAsync(_httpClient.BaseAddress + "/AdminFunction/ViewUsers").Result;
            //if (response.IsSuccessStatusCode)
            //{
            //    string data = response.Content.ReadAsStringAsync().Result;
            //    userList = JsonConvert.DeserializeObject<List<Login>>(data);
            //}
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> AddQuestion(Question question)
        {
            HttpResponseMessage response = await _httpClient.PostAsJsonAsync($"{basedaddress}/AdminFunction/AddQuestion", question);
            if (response.IsSuccessStatusCode)
            {
                return View("Index");
            }
            else
            {
                return BadRequest("Check once again");
            }
        }
        [HttpPost]
        public async Task<IActionResult> UpdateQuestion(Question question)
        {
            HttpResponseMessage response = await _httpClient.PostAsJsonAsync($"{basedaddress}/AdminFunction/UpdateQuestion", question);
            if (response.IsSuccessStatusCode)
            {
                return View("Index");
            }
            else
            {
                return BadRequest("Check once again");
            }
        }
        [HttpPost]
        public async Task<IActionResult> ViewQuestion(Question question)
        {
            HttpResponseMessage response = await _httpClient.PostAsJsonAsync($"{basedaddress}/AdminFunction/ViewQuestion", question);
            if (response.IsSuccessStatusCode)
            {
                return View("Index");
            }
            else
            {
                return BadRequest("Check once again");
            }
        }
        [HttpPost]
        public async Task<IActionResult> DeleteQuestion(Question question)
        {
            HttpResponseMessage response = await _httpClient.PostAsJsonAsync($"{basedaddress}/AdminFunction/DelteQuestion", question);
            if (response.IsSuccessStatusCode)
            {
                return View("Index");
            }
            else
            {
                return BadRequest("Check once again");
            }
        }

    }
}
