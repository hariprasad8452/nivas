﻿using Microsoft.AspNetCore.Mvc;
using OnlineWebAPI.Models;

namespace OnlineExamMVC.Controllers
{
    public class ExamController : Controller
    {
        public class ExamController1 : Controller
        {
            Uri basedaddress = new Uri("http://localhost:9748/api");
            private readonly HttpClient _httpClient;
            public ExamController1()
            {
                _httpClient = new HttpClient();
                _httpClient.BaseAddress = basedaddress;
            }
            public IActionResult Index()
            {
                return View();
            }
            public async Task<IActionResult> CreateExam(Exam exam)
            {
                HttpResponseMessage response = await _httpClient.PostAsJsonAsync($"{basedaddress}/Exam/CreateExam", exam);
                if (response.IsSuccessStatusCode)
                {
                    return View("Index");
                }
                else
                {
                    return BadRequest("Check once again");
                }
            }
            [HttpPost]
            public async Task<IActionResult> UpdateExam(Exam exam)
            {
                HttpResponseMessage response = await _httpClient.PostAsJsonAsync($"{basedaddress}/Exam/UpdateExam", exam);
                if (response.IsSuccessStatusCode)
                {
                    return View("Index");
                }
                else
                {
                    return BadRequest("Check once again");
                }
            }
            [HttpPost]
            public async Task<IActionResult> DeleteExam(Exam exam)
            {
                HttpResponseMessage response = await _httpClient.PostAsJsonAsync($"{basedaddress}/Exam/DeleteExam", exam);
                if (response.IsSuccessStatusCode)
                {
                    return View("Index");
                }
                else
                {
                    return BadRequest("Check once again");
                }
            }
        }
    }
}
