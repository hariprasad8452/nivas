﻿namespace OnlineWebAPI.Models
{
    public class LoginView
    {
        public string EmailId { get; set; }
        public string Password { get; set; }
        public string Role { get; set; }
    }
}
