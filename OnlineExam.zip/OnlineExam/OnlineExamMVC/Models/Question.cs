﻿using System.ComponentModel.DataAnnotations;

namespace OnlineWebAPI.Models
{
    public class Question
    {
        [Key]
        public int QuestionId { get; set; }
        public string QuestionText { get; set; }
        public string Option_1 { get; set; }
        public string Option_2 { get; set; }
        public string Option_3 { get; set; }
        public string Option_4 { get; set; }
        public string Answer { get; set; }
        public int ExamId { get; set; }
    }
}
