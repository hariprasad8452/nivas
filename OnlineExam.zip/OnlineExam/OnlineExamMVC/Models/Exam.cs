﻿using System.ComponentModel.DataAnnotations;

namespace OnlineWebAPI.Models
{
    public class Exam
    {
        [Key]
        public int ExamId { get; set; }
        public string ExamName { get; set; }
        public DateTime ExamDate { get; set; }
        //public TimeSpan ExamDuration { get; set; }
        public int ExamMarks { get; set; }
        public int CategoryId { get; set; }
        public virtual Category Category { get; set; }
        public ICollection<Question> questions { get; set; }
    }
}
